$(function(){

    $(".slide").slick({
      dots: true,
      slidesToShow: 1,
      slidesToScroll: 1
    });
  });